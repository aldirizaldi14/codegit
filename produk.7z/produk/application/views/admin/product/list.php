<!DOCTYPE html>
<html lang="en">

<head>
	<?php $this->load->view("admin/_partials/head.php") ?>
</head>

<body id="page-top">

	<?php $this->load->view("admin/_partials/navbar.php") ?>
	<div id="wrapper">

		<?php $this->load->view("admin/_partials/sidebar.php") ?>

		<div id="content-wrapper">

			<div class="container-fluid">

				<?php $this->load->view("admin/_partials/breadcrumb.php") ?>

				<!-- DataTables -->
				<div class="card mb-3">
					<div class="card-header">
						<a href="<?php echo site_url('admin/pegawai/add') ?>"><i class="fas fa-plus"></i> Add New</a>
					</div>
					<div class="card-body">
						
						<div class="table-responsive">
							<table class="table table-hover" id="dataTable" width="100%" cellspacing="0">
								<thead>
									<tr>
										<th>NIK</th>
										<th>No.Registrasi</th>
										<th>Nama</th>
										<th>Departement</th>
										<th>No.Telepon</th>
										<th>QR.Code</th>
									</tr>
								</thead>
								<tbody>
									<?php foreach ($pegawai as $product): ?>
									<tr>
										<td width="150">
											<?php echo $product->nik ?>
										</td>
										<td>
											<?php echo $product->noreg ?>
										</td>
										<td>
											<?php echo $product->nama ?>
										</td>
										<td>
											<?php echo $product->dept ?>
										</td>
										<td>
											<?php echo $product->telp ?>
										</td>
										<td>
											<img src="<?php echo base_url('assets/images/'.$product->qr_code) ?>">
										</td>
										<td width="250">
											<a href="<?php echo site_url('admin/pegawai/edit/'.$product->id_ku) ?>"
											 class="btn btn-small"><i class="fas fa-edit"></i> Edit</a>
											<a onclick="deleteConfirm('<?php echo site_url('admin/pegawai/delete/'.$product->id_ku) ?>')"
											 href="#!" class="btn btn-small text-danger"><i class="fas fa-trash"></i> Hapus</a>
										</td>
									</tr>
									<?php endforeach; ?>

								</tbody>
							</table>
						</div>
					</div>
				</div>

			</div>
			<!-- /.container-fluid -->

			<!-- Sticky Footer -->
			<?php $this->load->view("admin/_partials/footer.php") ?>

		</div>
		<!-- /.content-wrapper -->

	<script type="text/javascript" src="<?php echo base_url().'assets/js/jquery-2.1.4.min.js'?>"></script>
    <script type="text/javascript" src="<?php echo base_url().'assets/js/bootstrap.js'?>"></script>
	</div>
	<!-- /#wrapper -->



	<?php $this->load->view("admin/_partials/scrolltop.php") ?>
	<?php $this->load->view("admin/_partials/modal.php") ?>

	<?php $this->load->view("admin/_partials/js.php") ?>


	<script>
	function deleteConfirm(url){
		$('#btn-delete').attr('href', url);
		$('#deleteModal').modal();
	}
	</script>
</body>

</html>