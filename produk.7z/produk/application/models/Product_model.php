<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Product_model extends CI_Model
{
    private $_table = "pegawai";

    public $id_ku;
    public $nik;
    public $noreg;
    public $nama;
    public $dept;
    public $telp;
    public $qr_code;

    var $column_search = array('nik','nama','dept'); //set column field database for datatable searchable just firstname , lastname , address are searchable
 
    public function __construct()
    {
        parent::__construct();
        $this->load->database();
    }
 
    private function _get_datatables_query()
    {
         
        $this->db->from($this->table);
 
        $i = 0;
     
        foreach ($this->column_search as $item) // loop column 
        {
            if($_POST['search']['value']) // if datatable send POST for search
            {
                 
                if($i===0) // first loop
                {
                    $this->db->group_start(); // open bracket. query Where with OR clause better with bracket. because maybe can combine with other WHERE with AND.
                    $this->db->like($item, $_POST['search']['value']);
                }
                else
                {
                    $this->db->or_like($item, $_POST['search']['value']);
                }
 
                if(count($this->column_search) - 1 == $i) //last loop
                    $this->db->group_end(); //close bracket
            }
            $i++;
        }
         
        if(isset($_POST['order'])) // here order processing
        {
            $this->db->order_by($this->column_order[$_POST['order']['0']['column']], $_POST['order']['0']['dir']);
        } 
        else if(isset($this->order))
        {
            $order = $this->order;
            $this->db->order_by(key($order), $order[key($order)]);
        }
    }
 
    function get_datatables()
    {
        $this->_get_datatables_query();
        if($_POST['length'] != -1)
        $this->db->limit($_POST['length'], $_POST['start']);
        $query = $this->db->get();
        return $query->result();
    }
 
    function count_filtered()
    {
        $this->_get_datatables_query();
        $query = $this->db->get();
        return $query->num_rows();
    }
 

    public function rules()
    {
        return [
            ['field' => 'nik',
            'label' => 'NIK',
            'rules' => 'numeric'],

            ['field' => 'noreg',
            'label' => 'No.Registrasi',
            'rules' => 'numeric'],
            
            ['field' => 'nama',
            'label' => 'Nama',
            'rules' => 'required']

        
        ];
    }

    public function getAll()
    {
        return $this->db->get($this->_table)->result();
    }
    
    public function getById($id)
    {
        return $this->db->get_where($this->_table, ["id_ku" => $id])->row();
    }

    public function save()
    {
        $post = $this->input->post();
        $this->id_ku = uniqid();
        $this->nik = $post["nik"];
        $this->noreg = $post["noreg"];
        $this->nama = $post["nama"];
        $this->dept = $post["dept"];
        $this->telp = $post["telp"];    
        $this->db->insert($this->_table, $this);
    }

    public function update()
    {
        $post = $this->input->post();
        $this->id_ku = $post["id"];
        $this->nik = $post["nik"];
        $this->noreg = $post["noreg"];
        $this->nama = $post["nama"];
        $this->dept = $post["dept"];
        $this->telp = $post["telp"];
        $this->qr_code = $post["qr_code"];
        $this->db->update($this->_table, $this, array('id_ku' => $post['id']));
    }

    public function delete($id)
    {
       return $this->db->delete($this->_table, array("id_ku" => $id));
    }
}
